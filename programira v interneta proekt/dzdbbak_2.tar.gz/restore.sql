--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres2;
--
-- Name: postgres2; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres2 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE postgres2 OWNER TO postgres;

\connect postgres2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: week1; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.week1 (
    id integer NOT NULL,
    specialization_id integer,
    group_id integer,
    room_id integer,
    start_time time without time zone,
    end_time time without time zone,
    subject_id integer,
    subject_type_id integer,
    lecturer_id integer,
    day_of_week integer
);


ALTER TABLE public.week1 OWNER TO postgres;

--
-- Name: WEEK1_ID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.week1 ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public."WEEK1_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
    CYCLE
);


--
-- Name: class_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.class_groups (
    id integer NOT NULL,
    number_group text
);


ALTER TABLE public.class_groups OWNER TO postgres;

--
-- Name: class_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.class_groups ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.class_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: lecturers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lecturers (
    id integer NOT NULL,
    name_person text
);


ALTER TABLE public.lecturers OWNER TO postgres;

--
-- Name: lecturers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.lecturers ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.lecturers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rooms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rooms (
    id integer NOT NULL,
    room_number text
);


ALTER TABLE public.rooms OWNER TO postgres;

--
-- Name: rooms_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.rooms ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.rooms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: specializations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.specializations (
    id integer NOT NULL,
    name_specialization text
);


ALTER TABLE public.specializations OWNER TO postgres;

--
-- Name: specializations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.specializations ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.specializations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: subject_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subject_type (
    id integer NOT NULL,
    type_subject text
);


ALTER TABLE public.subject_type OWNER TO postgres;

--
-- Name: subject_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.subject_type ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.subject_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: subjects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subjects (
    id integer NOT NULL,
    name_subject text
);


ALTER TABLE public.subjects OWNER TO postgres;

--
-- Name: subjects_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.subjects ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.subjects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    user_name text NOT NULL,
    password_ text NOT NULL,
    is_admin boolean DEFAULT false
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.users ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: week10; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.week10 (
    id integer NOT NULL,
    specialization_id integer,
    group_id integer,
    room_id integer,
    start_time time without time zone,
    end_time time without time zone,
    subject_id integer,
    subject_type_id integer,
    lecturer_id integer,
    day_of_week integer,
    CONSTRAINT date_offset_0_6 CHECK (((day_of_week > '-1'::integer) AND (day_of_week < 7)))
);


ALTER TABLE public.week10 OWNER TO postgres;

--
-- Name: week10_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.week10 ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.week10_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
    CYCLE
);


--
-- Name: week11; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.week11 (
    id integer NOT NULL,
    specialization_id integer,
    group_id integer,
    room_id integer,
    start_time time without time zone,
    end_time time without time zone,
    subject_id integer,
    subject_type_id integer,
    lecturer_id integer,
    day_of_week integer,
    CONSTRAINT date_offset_0_6 CHECK (((day_of_week > '-1'::integer) AND (day_of_week < 7)))
);


ALTER TABLE public.week11 OWNER TO postgres;

--
-- Name: week11_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.week11 ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.week11_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
    CYCLE
);


--
-- Name: week12; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.week12 (
    id integer NOT NULL,
    specialization_id integer,
    group_id integer,
    room_id integer,
    start_time time without time zone,
    end_time time without time zone,
    subject_id integer,
    subject_type_id integer,
    lecturer_id integer,
    day_of_week integer,
    CONSTRAINT date_offset_0_6 CHECK (((day_of_week > '-1'::integer) AND (day_of_week < 7)))
);


ALTER TABLE public.week12 OWNER TO postgres;

--
-- Name: week12_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.week12 ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.week12_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
    CYCLE
);


--
-- Name: week13; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.week13 (
    id integer NOT NULL,
    specialization_id integer,
    group_id integer,
    room_id integer,
    start_time time without time zone,
    end_time time without time zone,
    subject_id integer,
    subject_type_id integer,
    lecturer_id integer,
    day_of_week integer,
    CONSTRAINT date_offset_0_6 CHECK (((day_of_week > '-1'::integer) AND (day_of_week < 7)))
);


ALTER TABLE public.week13 OWNER TO postgres;

--
-- Name: week13_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.week13 ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.week13_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
    CYCLE
);


--
-- Name: week2; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.week2 (
    id integer NOT NULL,
    specialization_id integer,
    group_id integer,
    room_id integer,
    start_time time without time zone,
    end_time time without time zone,
    subject_id integer,
    subject_type_id integer,
    lecturer_id integer,
    day_of_week integer,
    CONSTRAINT date_offset_0_6 CHECK (((day_of_week > '-1'::integer) AND (day_of_week < 7)))
);


ALTER TABLE public.week2 OWNER TO postgres;

--
-- Name: week2_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.week2 ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.week2_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
    CYCLE
);


--
-- Name: week3; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.week3 (
    id integer NOT NULL,
    specialization_id integer,
    group_id integer,
    room_id integer,
    start_time time without time zone,
    end_time time without time zone,
    subject_id integer,
    subject_type_id integer,
    lecturer_id integer,
    day_of_week integer,
    CONSTRAINT date_offset_0_6 CHECK (((day_of_week > '-1'::integer) AND (day_of_week < 7)))
);


ALTER TABLE public.week3 OWNER TO postgres;

--
-- Name: week3_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.week3 ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.week3_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
    CYCLE
);


--
-- Name: week4; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.week4 (
    id integer NOT NULL,
    specialization_id integer,
    group_id integer,
    room_id integer,
    start_time time without time zone,
    end_time time without time zone,
    subject_id integer,
    subject_type_id integer,
    lecturer_id integer,
    day_of_week integer,
    CONSTRAINT date_offset_0_6 CHECK (((day_of_week > '-1'::integer) AND (day_of_week < 7)))
);


ALTER TABLE public.week4 OWNER TO postgres;

--
-- Name: week4_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.week4 ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.week4_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
    CYCLE
);


--
-- Name: week5; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.week5 (
    id integer NOT NULL,
    specialization_id integer,
    group_id integer,
    room_id integer,
    start_time time without time zone,
    end_time time without time zone,
    subject_id integer,
    subject_type_id integer,
    lecturer_id integer,
    day_of_week integer,
    CONSTRAINT date_offset_0_6 CHECK (((day_of_week > '-1'::integer) AND (day_of_week < 7)))
);


ALTER TABLE public.week5 OWNER TO postgres;

--
-- Name: week5_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.week5 ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.week5_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
    CYCLE
);


--
-- Name: week6; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.week6 (
    id integer NOT NULL,
    specialization_id integer,
    group_id integer,
    room_id integer,
    start_time time without time zone,
    end_time time without time zone,
    subject_id integer,
    subject_type_id integer,
    lecturer_id integer,
    day_of_week integer,
    CONSTRAINT date_offset_0_6 CHECK (((day_of_week > '-1'::integer) AND (day_of_week < 7)))
);


ALTER TABLE public.week6 OWNER TO postgres;

--
-- Name: week6_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.week6 ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.week6_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
    CYCLE
);


--
-- Name: week7; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.week7 (
    id integer NOT NULL,
    specialization_id integer,
    group_id integer,
    room_id integer,
    start_time time without time zone,
    end_time time without time zone,
    subject_id integer,
    subject_type_id integer,
    lecturer_id integer,
    day_of_week integer,
    CONSTRAINT date_offset_0_6 CHECK (((day_of_week > '-1'::integer) AND (day_of_week < 7)))
);


ALTER TABLE public.week7 OWNER TO postgres;

--
-- Name: week7_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.week7 ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.week7_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
    CYCLE
);


--
-- Name: week8; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.week8 (
    id integer NOT NULL,
    specialization_id integer,
    group_id integer,
    room_id integer,
    start_time time without time zone,
    end_time time without time zone,
    subject_id integer,
    subject_type_id integer,
    lecturer_id integer,
    day_of_week integer,
    CONSTRAINT date_offset_0_6 CHECK (((day_of_week > '-1'::integer) AND (day_of_week < 7)))
);


ALTER TABLE public.week8 OWNER TO postgres;

--
-- Name: week8_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.week8 ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.week8_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
    CYCLE
);


--
-- Name: week9; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.week9 (
    id integer NOT NULL,
    specialization_id integer,
    group_id integer,
    room_id integer,
    start_time time without time zone,
    end_time time without time zone,
    subject_id integer,
    subject_type_id integer,
    lecturer_id integer,
    day_of_week integer,
    CONSTRAINT date_offset_0_6 CHECK (((day_of_week > '-1'::integer) AND (day_of_week < 7)))
);


ALTER TABLE public.week9 OWNER TO postgres;

--
-- Name: week9_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.week9 ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.week9_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
    CYCLE
);


--
-- Name: week_periods; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.week_periods (
    id integer NOT NULL,
    name_table text,
    date_start date,
    date_end date
);


ALTER TABLE public.week_periods OWNER TO postgres;

--
-- Data for Name: class_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.class_groups (id, number_group) FROM stdin;
\.
COPY public.class_groups (id, number_group) FROM '$$PATH$$/5081.dat';

--
-- Data for Name: lecturers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lecturers (id, name_person) FROM stdin;
\.
COPY public.lecturers (id, name_person) FROM '$$PATH$$/5079.dat';

--
-- Data for Name: rooms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rooms (id, room_number) FROM stdin;
\.
COPY public.rooms (id, room_number) FROM '$$PATH$$/5082.dat';

--
-- Data for Name: specializations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.specializations (id, name_specialization) FROM stdin;
\.
COPY public.specializations (id, name_specialization) FROM '$$PATH$$/5080.dat';

--
-- Data for Name: subject_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subject_type (id, type_subject) FROM stdin;
\.
COPY public.subject_type (id, type_subject) FROM '$$PATH$$/5084.dat';

--
-- Data for Name: subjects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subjects (id, name_subject) FROM stdin;
\.
COPY public.subjects (id, name_subject) FROM '$$PATH$$/5083.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, user_name, password_, is_admin) FROM stdin;
\.
COPY public.users (id, user_name, password_, is_admin) FROM '$$PATH$$/5092.dat';

--
-- Data for Name: week1; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.week1 (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week) FROM stdin;
\.
COPY public.week1 (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week) FROM '$$PATH$$/5078.dat';

--
-- Data for Name: week10; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.week10 (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week) FROM stdin;
\.
COPY public.week10 (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week) FROM '$$PATH$$/5111.dat';

--
-- Data for Name: week11; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.week11 (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week) FROM stdin;
\.
COPY public.week11 (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week) FROM '$$PATH$$/5113.dat';

--
-- Data for Name: week12; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.week12 (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week) FROM stdin;
\.
COPY public.week12 (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week) FROM '$$PATH$$/5115.dat';

--
-- Data for Name: week13; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.week13 (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week) FROM stdin;
\.
COPY public.week13 (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week) FROM '$$PATH$$/5117.dat';

--
-- Data for Name: week2; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.week2 (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week) FROM stdin;
\.
COPY public.week2 (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week) FROM '$$PATH$$/5097.dat';

--
-- Data for Name: week3; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.week3 (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week) FROM stdin;
\.
COPY public.week3 (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week) FROM '$$PATH$$/5095.dat';

--
-- Data for Name: week4; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.week4 (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week) FROM stdin;
\.
COPY public.week4 (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week) FROM '$$PATH$$/5099.dat';

--
-- Data for Name: week5; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.week5 (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week) FROM stdin;
\.
COPY public.week5 (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week) FROM '$$PATH$$/5101.dat';

--
-- Data for Name: week6; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.week6 (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week) FROM stdin;
\.
COPY public.week6 (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week) FROM '$$PATH$$/5103.dat';

--
-- Data for Name: week7; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.week7 (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week) FROM stdin;
\.
COPY public.week7 (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week) FROM '$$PATH$$/5105.dat';

--
-- Data for Name: week8; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.week8 (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week) FROM stdin;
\.
COPY public.week8 (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week) FROM '$$PATH$$/5107.dat';

--
-- Data for Name: week9; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.week9 (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week) FROM stdin;
\.
COPY public.week9 (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week) FROM '$$PATH$$/5109.dat';

--
-- Data for Name: week_periods; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.week_periods (id, name_table, date_start, date_end) FROM stdin;
\.
COPY public.week_periods (id, name_table, date_start, date_end) FROM '$$PATH$$/5085.dat';

--
-- Name: WEEK1_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."WEEK1_ID_seq"', 96, true);


--
-- Name: class_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.class_groups_id_seq', 17, true);


--
-- Name: lecturers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lecturers_id_seq', 5, true);


--
-- Name: rooms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rooms_id_seq', 23, true);


--
-- Name: specializations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.specializations_id_seq', 11, true);


--
-- Name: subject_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.subject_type_id_seq', 6, true);


--
-- Name: subjects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.subjects_id_seq', 15, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- Name: week10_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.week10_id_seq', 58, true);


--
-- Name: week11_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.week11_id_seq', 57, true);


--
-- Name: week12_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.week12_id_seq', 37, true);


--
-- Name: week13_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.week13_id_seq', 20, true);


--
-- Name: week2_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.week2_id_seq', 55, true);


--
-- Name: week3_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.week3_id_seq', 61, true);


--
-- Name: week4_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.week4_id_seq', 60, true);


--
-- Name: week5_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.week5_id_seq', 58, true);


--
-- Name: week6_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.week6_id_seq', 61, true);


--
-- Name: week7_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.week7_id_seq', 62, true);


--
-- Name: week8_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.week8_id_seq', 57, true);


--
-- Name: week9_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.week9_id_seq', 57, true);


--
-- Name: week1 date_offset_0_6; Type: CHECK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE public.week1
    ADD CONSTRAINT date_offset_0_6 CHECK (((day_of_week > '-1'::integer) AND (day_of_week < 7))) NOT VALID;


--
-- Name: class_groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: lecturers lecturers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lecturers
    ADD CONSTRAINT lecturers_pkey PRIMARY KEY (id);


--
-- Name: rooms rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (id);


--
-- Name: specializations specializations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.specializations
    ADD CONSTRAINT specializations_pkey PRIMARY KEY (id);


--
-- Name: subject_type subject_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subject_type
    ADD CONSTRAINT subject_type_pkey PRIMARY KEY (id);


--
-- Name: subjects subjects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: week10 week10_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week10
    ADD CONSTRAINT week10_pkey PRIMARY KEY (id);


--
-- Name: week11 week11_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week11
    ADD CONSTRAINT week11_pkey PRIMARY KEY (id);


--
-- Name: week12 week12_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week12
    ADD CONSTRAINT week12_pkey PRIMARY KEY (id);


--
-- Name: week13 week13_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week13
    ADD CONSTRAINT week13_pkey PRIMARY KEY (id);


--
-- Name: week1 week1_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week1
    ADD CONSTRAINT week1_pkey PRIMARY KEY (id);


--
-- Name: week2 week2_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week2
    ADD CONSTRAINT week2_pkey PRIMARY KEY (id);


--
-- Name: week3 week3_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week3
    ADD CONSTRAINT week3_pkey PRIMARY KEY (id);


--
-- Name: week4 week4_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week4
    ADD CONSTRAINT week4_pkey PRIMARY KEY (id);


--
-- Name: week5 week5_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week5
    ADD CONSTRAINT week5_pkey PRIMARY KEY (id);


--
-- Name: week6 week6_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week6
    ADD CONSTRAINT week6_pkey PRIMARY KEY (id);


--
-- Name: week7 week7_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week7
    ADD CONSTRAINT week7_pkey PRIMARY KEY (id);


--
-- Name: week8 week8_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week8
    ADD CONSTRAINT week8_pkey PRIMARY KEY (id);


--
-- Name: week9 week9_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week9
    ADD CONSTRAINT week9_pkey PRIMARY KEY (id);


--
-- Name: week_periods week_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week_periods
    ADD CONSTRAINT week_periods_pkey PRIMARY KEY (id);


--
-- Name: week1 groups; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week1
    ADD CONSTRAINT groups FOREIGN KEY (group_id) REFERENCES public.class_groups(id) NOT VALID;


--
-- Name: week3 groups; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week3
    ADD CONSTRAINT groups FOREIGN KEY (group_id) REFERENCES public.class_groups(id);


--
-- Name: week2 groups; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week2
    ADD CONSTRAINT groups FOREIGN KEY (group_id) REFERENCES public.class_groups(id);


--
-- Name: week4 groups; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week4
    ADD CONSTRAINT groups FOREIGN KEY (group_id) REFERENCES public.class_groups(id);


--
-- Name: week5 groups; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week5
    ADD CONSTRAINT groups FOREIGN KEY (group_id) REFERENCES public.class_groups(id);


--
-- Name: week6 groups; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week6
    ADD CONSTRAINT groups FOREIGN KEY (group_id) REFERENCES public.class_groups(id);


--
-- Name: week7 groups; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week7
    ADD CONSTRAINT groups FOREIGN KEY (group_id) REFERENCES public.class_groups(id);


--
-- Name: week8 groups; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week8
    ADD CONSTRAINT groups FOREIGN KEY (group_id) REFERENCES public.class_groups(id);


--
-- Name: week9 groups; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week9
    ADD CONSTRAINT groups FOREIGN KEY (group_id) REFERENCES public.class_groups(id);


--
-- Name: week10 groups; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week10
    ADD CONSTRAINT groups FOREIGN KEY (group_id) REFERENCES public.class_groups(id);


--
-- Name: week11 groups; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week11
    ADD CONSTRAINT groups FOREIGN KEY (group_id) REFERENCES public.class_groups(id);


--
-- Name: week12 groups; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week12
    ADD CONSTRAINT groups FOREIGN KEY (group_id) REFERENCES public.class_groups(id);


--
-- Name: week13 groups; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week13
    ADD CONSTRAINT groups FOREIGN KEY (group_id) REFERENCES public.class_groups(id);


--
-- Name: week1 lecturers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week1
    ADD CONSTRAINT lecturers FOREIGN KEY (lecturer_id) REFERENCES public.lecturers(id) NOT VALID;


--
-- Name: week3 lecturers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week3
    ADD CONSTRAINT lecturers FOREIGN KEY (lecturer_id) REFERENCES public.lecturers(id);


--
-- Name: week2 lecturers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week2
    ADD CONSTRAINT lecturers FOREIGN KEY (lecturer_id) REFERENCES public.lecturers(id);


--
-- Name: week4 lecturers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week4
    ADD CONSTRAINT lecturers FOREIGN KEY (lecturer_id) REFERENCES public.lecturers(id);


--
-- Name: week5 lecturers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week5
    ADD CONSTRAINT lecturers FOREIGN KEY (lecturer_id) REFERENCES public.lecturers(id);


--
-- Name: week6 lecturers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week6
    ADD CONSTRAINT lecturers FOREIGN KEY (lecturer_id) REFERENCES public.lecturers(id);


--
-- Name: week7 lecturers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week7
    ADD CONSTRAINT lecturers FOREIGN KEY (lecturer_id) REFERENCES public.lecturers(id);


--
-- Name: week8 lecturers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week8
    ADD CONSTRAINT lecturers FOREIGN KEY (lecturer_id) REFERENCES public.lecturers(id);


--
-- Name: week9 lecturers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week9
    ADD CONSTRAINT lecturers FOREIGN KEY (lecturer_id) REFERENCES public.lecturers(id);


--
-- Name: week10 lecturers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week10
    ADD CONSTRAINT lecturers FOREIGN KEY (lecturer_id) REFERENCES public.lecturers(id);


--
-- Name: week11 lecturers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week11
    ADD CONSTRAINT lecturers FOREIGN KEY (lecturer_id) REFERENCES public.lecturers(id);


--
-- Name: week12 lecturers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week12
    ADD CONSTRAINT lecturers FOREIGN KEY (lecturer_id) REFERENCES public.lecturers(id);


--
-- Name: week13 lecturers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week13
    ADD CONSTRAINT lecturers FOREIGN KEY (lecturer_id) REFERENCES public.lecturers(id);


--
-- Name: week1 rooms; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week1
    ADD CONSTRAINT rooms FOREIGN KEY (room_id) REFERENCES public.rooms(id) NOT VALID;


--
-- Name: week3 rooms; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week3
    ADD CONSTRAINT rooms FOREIGN KEY (room_id) REFERENCES public.rooms(id);


--
-- Name: week2 rooms; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week2
    ADD CONSTRAINT rooms FOREIGN KEY (room_id) REFERENCES public.rooms(id);


--
-- Name: week4 rooms; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week4
    ADD CONSTRAINT rooms FOREIGN KEY (room_id) REFERENCES public.rooms(id);


--
-- Name: week5 rooms; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week5
    ADD CONSTRAINT rooms FOREIGN KEY (room_id) REFERENCES public.rooms(id);


--
-- Name: week6 rooms; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week6
    ADD CONSTRAINT rooms FOREIGN KEY (room_id) REFERENCES public.rooms(id);


--
-- Name: week7 rooms; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week7
    ADD CONSTRAINT rooms FOREIGN KEY (room_id) REFERENCES public.rooms(id);


--
-- Name: week8 rooms; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week8
    ADD CONSTRAINT rooms FOREIGN KEY (room_id) REFERENCES public.rooms(id);


--
-- Name: week9 rooms; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week9
    ADD CONSTRAINT rooms FOREIGN KEY (room_id) REFERENCES public.rooms(id);


--
-- Name: week10 rooms; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week10
    ADD CONSTRAINT rooms FOREIGN KEY (room_id) REFERENCES public.rooms(id);


--
-- Name: week11 rooms; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week11
    ADD CONSTRAINT rooms FOREIGN KEY (room_id) REFERENCES public.rooms(id);


--
-- Name: week12 rooms; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week12
    ADD CONSTRAINT rooms FOREIGN KEY (room_id) REFERENCES public.rooms(id);


--
-- Name: week13 rooms; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week13
    ADD CONSTRAINT rooms FOREIGN KEY (room_id) REFERENCES public.rooms(id);


--
-- Name: week1 specializations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week1
    ADD CONSTRAINT specializations FOREIGN KEY (specialization_id) REFERENCES public.specializations(id) NOT VALID;


--
-- Name: week3 specializations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week3
    ADD CONSTRAINT specializations FOREIGN KEY (specialization_id) REFERENCES public.specializations(id);


--
-- Name: week2 specializations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week2
    ADD CONSTRAINT specializations FOREIGN KEY (specialization_id) REFERENCES public.specializations(id);


--
-- Name: week4 specializations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week4
    ADD CONSTRAINT specializations FOREIGN KEY (specialization_id) REFERENCES public.specializations(id);


--
-- Name: week5 specializations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week5
    ADD CONSTRAINT specializations FOREIGN KEY (specialization_id) REFERENCES public.specializations(id);


--
-- Name: week6 specializations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week6
    ADD CONSTRAINT specializations FOREIGN KEY (specialization_id) REFERENCES public.specializations(id);


--
-- Name: week7 specializations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week7
    ADD CONSTRAINT specializations FOREIGN KEY (specialization_id) REFERENCES public.specializations(id);


--
-- Name: week8 specializations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week8
    ADD CONSTRAINT specializations FOREIGN KEY (specialization_id) REFERENCES public.specializations(id);


--
-- Name: week9 specializations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week9
    ADD CONSTRAINT specializations FOREIGN KEY (specialization_id) REFERENCES public.specializations(id);


--
-- Name: week10 specializations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week10
    ADD CONSTRAINT specializations FOREIGN KEY (specialization_id) REFERENCES public.specializations(id);


--
-- Name: week11 specializations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week11
    ADD CONSTRAINT specializations FOREIGN KEY (specialization_id) REFERENCES public.specializations(id);


--
-- Name: week12 specializations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week12
    ADD CONSTRAINT specializations FOREIGN KEY (specialization_id) REFERENCES public.specializations(id);


--
-- Name: week13 specializations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week13
    ADD CONSTRAINT specializations FOREIGN KEY (specialization_id) REFERENCES public.specializations(id);


--
-- Name: week1 subject; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week1
    ADD CONSTRAINT subject FOREIGN KEY (subject_id) REFERENCES public.subjects(id) NOT VALID;


--
-- Name: week3 subject; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week3
    ADD CONSTRAINT subject FOREIGN KEY (subject_id) REFERENCES public.subjects(id);


--
-- Name: week2 subject; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week2
    ADD CONSTRAINT subject FOREIGN KEY (subject_id) REFERENCES public.subjects(id);


--
-- Name: week4 subject; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week4
    ADD CONSTRAINT subject FOREIGN KEY (subject_id) REFERENCES public.subjects(id);


--
-- Name: week5 subject; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week5
    ADD CONSTRAINT subject FOREIGN KEY (subject_id) REFERENCES public.subjects(id);


--
-- Name: week6 subject; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week6
    ADD CONSTRAINT subject FOREIGN KEY (subject_id) REFERENCES public.subjects(id);


--
-- Name: week7 subject; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week7
    ADD CONSTRAINT subject FOREIGN KEY (subject_id) REFERENCES public.subjects(id);


--
-- Name: week8 subject; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week8
    ADD CONSTRAINT subject FOREIGN KEY (subject_id) REFERENCES public.subjects(id);


--
-- Name: week9 subject; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week9
    ADD CONSTRAINT subject FOREIGN KEY (subject_id) REFERENCES public.subjects(id);


--
-- Name: week10 subject; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week10
    ADD CONSTRAINT subject FOREIGN KEY (subject_id) REFERENCES public.subjects(id);


--
-- Name: week11 subject; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week11
    ADD CONSTRAINT subject FOREIGN KEY (subject_id) REFERENCES public.subjects(id);


--
-- Name: week12 subject; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week12
    ADD CONSTRAINT subject FOREIGN KEY (subject_id) REFERENCES public.subjects(id);


--
-- Name: week13 subject; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week13
    ADD CONSTRAINT subject FOREIGN KEY (subject_id) REFERENCES public.subjects(id);


--
-- Name: week1 subject_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week1
    ADD CONSTRAINT subject_type FOREIGN KEY (subject_type_id) REFERENCES public.subject_type(id) NOT VALID;


--
-- Name: week3 subject_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week3
    ADD CONSTRAINT subject_type FOREIGN KEY (subject_type_id) REFERENCES public.subject_type(id);


--
-- Name: week2 subject_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week2
    ADD CONSTRAINT subject_type FOREIGN KEY (subject_type_id) REFERENCES public.subject_type(id);


--
-- Name: week4 subject_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week4
    ADD CONSTRAINT subject_type FOREIGN KEY (subject_type_id) REFERENCES public.subject_type(id);


--
-- Name: week5 subject_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week5
    ADD CONSTRAINT subject_type FOREIGN KEY (subject_type_id) REFERENCES public.subject_type(id);


--
-- Name: week6 subject_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week6
    ADD CONSTRAINT subject_type FOREIGN KEY (subject_type_id) REFERENCES public.subject_type(id);


--
-- Name: week7 subject_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week7
    ADD CONSTRAINT subject_type FOREIGN KEY (subject_type_id) REFERENCES public.subject_type(id);


--
-- Name: week8 subject_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week8
    ADD CONSTRAINT subject_type FOREIGN KEY (subject_type_id) REFERENCES public.subject_type(id);


--
-- Name: week9 subject_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week9
    ADD CONSTRAINT subject_type FOREIGN KEY (subject_type_id) REFERENCES public.subject_type(id);


--
-- Name: week10 subject_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week10
    ADD CONSTRAINT subject_type FOREIGN KEY (subject_type_id) REFERENCES public.subject_type(id);


--
-- Name: week11 subject_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week11
    ADD CONSTRAINT subject_type FOREIGN KEY (subject_type_id) REFERENCES public.subject_type(id);


--
-- Name: week12 subject_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week12
    ADD CONSTRAINT subject_type FOREIGN KEY (subject_type_id) REFERENCES public.subject_type(id);


--
-- Name: week13 subject_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week13
    ADD CONSTRAINT subject_type FOREIGN KEY (subject_type_id) REFERENCES public.subject_type(id);


--
-- Name: week1; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.week1 ENABLE ROW LEVEL SECURITY;

--
-- Name: week10; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.week10 ENABLE ROW LEVEL SECURITY;

--
-- Name: week11; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.week11 ENABLE ROW LEVEL SECURITY;

--
-- Name: week12; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.week12 ENABLE ROW LEVEL SECURITY;

--
-- Name: week13; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.week13 ENABLE ROW LEVEL SECURITY;

--
-- Name: week2; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.week2 ENABLE ROW LEVEL SECURITY;

--
-- Name: week3; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.week3 ENABLE ROW LEVEL SECURITY;

--
-- Name: week4; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.week4 ENABLE ROW LEVEL SECURITY;

--
-- Name: week5; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.week5 ENABLE ROW LEVEL SECURITY;

--
-- Name: week6; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.week6 ENABLE ROW LEVEL SECURITY;

--
-- Name: week7; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.week7 ENABLE ROW LEVEL SECURITY;

--
-- Name: week8; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.week8 ENABLE ROW LEVEL SECURITY;

--
-- Name: week9; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.week9 ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

