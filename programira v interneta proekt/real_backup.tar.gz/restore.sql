--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.6
-- Dumped by pg_dump version 16.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE postgres2;
--
-- Name: postgres2; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE postgres2 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE postgres2 OWNER TO postgres;

\connect postgres2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: all_week_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.all_week_data (
    id integer NOT NULL,
    specialization_id integer,
    group_id integer,
    room_id integer,
    start_time time without time zone,
    end_time time without time zone,
    subject_id integer,
    subject_type_id integer,
    lecturer_id integer,
    day_of_week integer,
    week integer NOT NULL,
    entry_by_user text DEFAULT ''::text NOT NULL,
    CONSTRAINT date_offset_0_6 CHECK (((day_of_week > '-1'::integer) AND (day_of_week < 7)))
);


ALTER TABLE public.all_week_data OWNER TO postgres;

--
-- Name: all_week_data_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.all_week_data ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.all_week_data_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
    CYCLE
);


--
-- Name: class_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.class_groups (
    id integer NOT NULL,
    number_group text
);


ALTER TABLE public.class_groups OWNER TO postgres;

--
-- Name: class_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.class_groups ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.class_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: lecturers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lecturers (
    id integer NOT NULL,
    name_person text
);


ALTER TABLE public.lecturers OWNER TO postgres;

--
-- Name: lecturers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.lecturers ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.lecturers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: rooms; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.rooms (
    id integer NOT NULL,
    room_number text
);


ALTER TABLE public.rooms OWNER TO postgres;

--
-- Name: rooms_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.rooms ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.rooms_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: specializations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.specializations (
    id integer NOT NULL,
    name_specialization text
);


ALTER TABLE public.specializations OWNER TO postgres;

--
-- Name: specializations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.specializations ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.specializations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: subject_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subject_type (
    id integer NOT NULL,
    type_subject text
);


ALTER TABLE public.subject_type OWNER TO postgres;

--
-- Name: subject_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.subject_type ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.subject_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: subjects; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.subjects (
    id integer NOT NULL,
    name_subject text
);


ALTER TABLE public.subjects OWNER TO postgres;

--
-- Name: subjects_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.subjects ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.subjects_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    user_name text NOT NULL,
    password_ text NOT NULL,
    is_admin boolean DEFAULT false
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.users ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: week_periods; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.week_periods (
    id integer NOT NULL,
    name_table text,
    date_start date,
    date_end date
);


ALTER TABLE public.week_periods OWNER TO postgres;

--
-- Data for Name: all_week_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.all_week_data (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week, week, entry_by_user) FROM stdin;
\.
COPY public.all_week_data (id, specialization_id, group_id, room_id, start_time, end_time, subject_id, subject_type_id, lecturer_id, day_of_week, week, entry_by_user) FROM '$$PATH$$/4916.dat';

--
-- Data for Name: class_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.class_groups (id, number_group) FROM stdin;
\.
COPY public.class_groups (id, number_group) FROM '$$PATH$$/4902.dat';

--
-- Data for Name: lecturers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lecturers (id, name_person) FROM stdin;
\.
COPY public.lecturers (id, name_person) FROM '$$PATH$$/4900.dat';

--
-- Data for Name: rooms; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.rooms (id, room_number) FROM stdin;
\.
COPY public.rooms (id, room_number) FROM '$$PATH$$/4903.dat';

--
-- Data for Name: specializations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.specializations (id, name_specialization) FROM stdin;
\.
COPY public.specializations (id, name_specialization) FROM '$$PATH$$/4901.dat';

--
-- Data for Name: subject_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subject_type (id, type_subject) FROM stdin;
\.
COPY public.subject_type (id, type_subject) FROM '$$PATH$$/4905.dat';

--
-- Data for Name: subjects; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.subjects (id, name_subject) FROM stdin;
\.
COPY public.subjects (id, name_subject) FROM '$$PATH$$/4904.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, user_name, password_, is_admin) FROM stdin;
\.
COPY public.users (id, user_name, password_, is_admin) FROM '$$PATH$$/4913.dat';

--
-- Data for Name: week_periods; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.week_periods (id, name_table, date_start, date_end) FROM stdin;
\.
COPY public.week_periods (id, name_table, date_start, date_end) FROM '$$PATH$$/4906.dat';

--
-- Name: all_week_data_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.all_week_data_id_seq', 1909, true);


--
-- Name: class_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.class_groups_id_seq', 19, true);


--
-- Name: lecturers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lecturers_id_seq', 9, true);


--
-- Name: rooms_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.rooms_id_seq', 26, true);


--
-- Name: specializations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.specializations_id_seq', 14, true);


--
-- Name: subject_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.subject_type_id_seq', 6, true);


--
-- Name: subjects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.subjects_id_seq', 18, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- Name: all_week_data all_week_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.all_week_data
    ADD CONSTRAINT all_week_data_pkey PRIMARY KEY (id);


--
-- Name: class_groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.class_groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- Name: lecturers lecturers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lecturers
    ADD CONSTRAINT lecturers_pkey PRIMARY KEY (id);


--
-- Name: rooms rooms_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.rooms
    ADD CONSTRAINT rooms_pkey PRIMARY KEY (id);


--
-- Name: specializations specializations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.specializations
    ADD CONSTRAINT specializations_pkey PRIMARY KEY (id);


--
-- Name: subject_type subject_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subject_type
    ADD CONSTRAINT subject_type_pkey PRIMARY KEY (id);


--
-- Name: subjects subjects_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.subjects
    ADD CONSTRAINT subjects_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: week_periods week_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.week_periods
    ADD CONSTRAINT week_periods_pkey PRIMARY KEY (id);


--
-- Name: fki_week; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_week ON public.all_week_data USING btree (week);


--
-- Name: all_week_data groups; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.all_week_data
    ADD CONSTRAINT groups FOREIGN KEY (group_id) REFERENCES public.class_groups(id);


--
-- Name: all_week_data lecturers; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.all_week_data
    ADD CONSTRAINT lecturers FOREIGN KEY (lecturer_id) REFERENCES public.lecturers(id);


--
-- Name: all_week_data rooms; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.all_week_data
    ADD CONSTRAINT rooms FOREIGN KEY (room_id) REFERENCES public.rooms(id);


--
-- Name: all_week_data specializations; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.all_week_data
    ADD CONSTRAINT specializations FOREIGN KEY (specialization_id) REFERENCES public.specializations(id);


--
-- Name: all_week_data subject; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.all_week_data
    ADD CONSTRAINT subject FOREIGN KEY (subject_id) REFERENCES public.subjects(id);


--
-- Name: all_week_data subject_type; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.all_week_data
    ADD CONSTRAINT subject_type FOREIGN KEY (subject_type_id) REFERENCES public.subject_type(id);


--
-- Name: all_week_data week; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.all_week_data
    ADD CONSTRAINT week FOREIGN KEY (week) REFERENCES public.week_periods(id) NOT VALID;


--
-- Name: all_week_data; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.all_week_data ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

